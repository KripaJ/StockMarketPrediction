from django.apps import AppConfig


class pred_appConfig(AppConfig):
    name = 'pred_app'
