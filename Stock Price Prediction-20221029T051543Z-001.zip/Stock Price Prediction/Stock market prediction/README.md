# stock-price-forecster-lstm
A Django app to predict realtime stock market prices for NSE and NYSE using LSTM machine learning model.
Users can select from a predefined list of stock names to predict the prices.
## Built With

* [Django](https://www.djangoproject.com/) - Django 3.0
* [Python](https://www.python.org/) - Python 3.7.x
